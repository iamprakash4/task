import React from 'react';
import { Field, reduxForm, SubmissionError} from 'redux-form';
import {FormLabel} from '../FormLabel';
import { makeStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';

import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardMedia from '@material-ui/core/CardMedia';
import 'object-assign';

const useStyles = makeStyles((theme) => ({
    root: {
    //   maxWidth: 345,
    },
    media: {
      height: 0,
      paddingTop: '56.25%', // 16:9
    },
    text: {
        margin: theme.spacing(1),
        width: '25ch',
      },
  }));
  
const submit = ({searchValue = ''}, submitAction, reset, handleCount) => {
    let error = {};
    let isError = false;
    if(searchValue.trim() === '') {
        error.searchValue = 'required*';
        isError = true;
    }
    if (isError) {
        throw new SubmissionError(error);
    } else {
        submitAction({searchValue});
        handleCount(1);
        reset();
    }
};

const renderField = ({type,placeholder,  label, input,  meta: {touched, error}}) => (
    <span className='field'>
        <input {...input} type={type} className='' placeholder={placeholder} />
        {touched && error && <span className='error'>{error}</span>}
    </span>
);

const ContactFormFunc = (props) => {
    const {handleSubmit, submitAction, reset, valueList, count,handleCount} = props
    const classes = useStyles();
    return (
        <Grid key = {'a'} container className={classes.root} spacing={2}>
            <div style={{padding:'50px'}}>
                <Grid key = {'b'} item xs={12} >
                 <form onSubmit={handleSubmit((fields) => submit(fields, submitAction, reset, handleCount))} id='form1' className='mLabForm'>
                    <div className='form-row'>
                        <FormLabel labelName={'searchValue'} fieldName={'Search something'}  />
                        <Field component={renderField} type='text' placeholder='' name='searchValue' id='searchValue' />
                    </div>
                    <div className={`submitBtn u-mt30 u-mb80`}>
                        <button type='submit'>submit</button>
                    </div>
                    <div> 
                        <div>
                            search count : {count}
                        </div>
                    </div>
             </form>
                </Grid>
            <Grid key = {'c'} item xs={12}>
                <Grid key = {'d'} container  justify="center" spacing={2}>
                {Object.keys(valueList).length >0 && valueList.data.map((value) => (
                    <Grid xs={4} key={value} item >
                        <Paper className={classes.paper}>
                            <Card className={classes.paper} >
                            <CardHeader
                            
                                title={value.title.length < 45 ? value.title :value.title.slice(0, 45) + '...' }
                                subheader={value.type}
                            />
                            <CardMedia
                                className={classes.media}
                                image={value.images.original.url}
                                title={value.title}
                            />
                            </Card>
                        </Paper>
                    </Grid>
                ))}
                </Grid>
            </Grid>
            </div>
          
        </Grid>
        )
}
const ContactForm = reduxForm({
    form: 'contact',
})(ContactFormFunc);

export default ContactForm;