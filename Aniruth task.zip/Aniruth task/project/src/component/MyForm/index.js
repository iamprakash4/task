import React,{Component} from 'react';
import { connect } from 'react-redux';
import {submitAction} from '../../actions/submitAction';
import {defaultAction} from '../../actions/submitAction';
import MyForm from './MyForm';

class Sample extends Component{
    constructor(){
        super();
        this.state = {
            receiveValues:{},
            valueList :{},
            count : 0
        }
    }

    componentDidMount(){
        this.props.defaultAction();
    }

    componentWillReceiveProps(nextProps){
        if(nextProps.receiveValues.success && nextProps.receiveValues.success !== this.state.valueList){
         this.setState({
            valueList: nextProps.receiveValues.success.submitErrors
         })
        }
      }

    submitAction =(value) =>{
        this.props.submitAction(value);
    }

    handleCount = (value) => {
        this.setState({
            count : this.state.count + value
        })
    }
    render(){
        return<MyForm 
            submitAction ={this.submitAction} 
            valueList = {this.state.valueList} 
            count = {this.state.count} handleCount={this.handleCount} 
        />
    }
}
const mapStateToProps = state =>{
    return {
        receiveValues :  state.form
    }
} 
  
const mapDispatchToProps = dispatch => ({
    defaultAction:()=>dispatch(defaultAction()),
    submitAction: (data) => dispatch(submitAction(data)),
});
  
  export default connect(mapStateToProps, mapDispatchToProps)(Sample);
