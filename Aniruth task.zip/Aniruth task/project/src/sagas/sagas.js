

import { takeLatest, call, fork, put } from 'redux-saga/effects';
import { stopSubmit } from 'redux-form';

function submitToServer(data){
return fetch(`https://cors-anywhere.herokuapp.com/http://api.giphy.com/v1/gifs/search?q=${data.searchValue}&api_key=Ampqrh8rYCS6WBaIIL2VkrPMo0kTSrZd&limit=9`, {
    method: 'GET',
    headers: {
        'X-Requested-With': 'XMLHttpRequest'
    },
}).then( res => res.json()).catch(error => console.error(error));
}

function defaultToServer(){
return fetch(`https://cors-anywhere.herokuapp.com/http://api.giphy.com/v1/gifs/trending?&api_key=Ampqrh8rYCS6WBaIIL2VkrPMo0kTSrZd&limit=9`, {
    method: 'GET',
    headers: {
        'X-Requested-With': 'XMLHttpRequest'
    },
}).then( res => res.json()).catch(error => console.error(error));
}


function* callSubmit(action){
    const result = yield call(submitToServer, action.data);
    if(result.errors){
        yield put({ type: 'REQUEST_FAILED', errors: result.errors});
    }else {
       yield put({ type: 'REQUEST_SUCCESSFULL', success: result});
    }
    yield put(stopSubmit('success', result));
}

function* defaultLoad(){
        const result = yield call(defaultToServer);
        if(result.errors){
            yield put({ type: 'REQUEST_FAILED', errors: result.errors});
        }else {
           yield put({ type: 'REQUEST_SUCCESSFULL', success: result});
        }
        yield put(stopSubmit('success', result));
}

function* submitSaga(){
   yield takeLatest('REQUEST_SUBMIT', callSubmit);
   yield takeLatest('DEFAULT_SUBMIT', defaultLoad);
}

export function* rootSaga(){
    yield [
        fork(submitSaga)
    ]
}
