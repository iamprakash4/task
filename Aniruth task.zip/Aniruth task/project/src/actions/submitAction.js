export const submitAction = (data) => ({
    type: 'REQUEST_SUBMIT',
    data,
});
export const defaultAction = () => ({
    type: 'DEFAULT_SUBMIT',
});

