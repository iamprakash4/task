import React, { Component } from 'react';
import { deviceGet,deviceUpdate,deviceAdd,deviceDelete,deviceState,getEmailList,deviceShare } from '../actions/device';
import { connect } from 'react-redux';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';

class Protected extends Component {
  constructor(){
    super();
    this.state={
      deviceList :[],
      deviceAdd :{},  
      deviceUpdate :{},
      deviceDelete :{},
      deviceState:{},
      deviceShare:{},
      emailList:[],
      showModal:false,
      updateDevice:{},
      modalCheck:[],
      updateOpen: false,
      addOpen:false,
      addDevice: {},
      alertOpen:false,
      alertInfo:{},
      alertObj:{},
      alertType:'',
      shareObj:{},
      shareOpen:false,
      selectedEmail:''
    }
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.deviceList !== nextProps.deviceList) {
     this.setState({
      deviceList:nextProps.deviceList
     });
    }
    if (this.props.deviceAdd !== nextProps.deviceAdd) {
      this.setState({
        deviceAdd:nextProps.deviceAdd
      });
     }
     if (this.props.deviceUpdate !== nextProps.deviceUpdate) {
      this.setState({
        deviceUpdate:nextProps.deviceUpdate
      });
     }
     if (this.props.deviceDelete !== nextProps.deviceDelete) {
      this.setState({
        deviceDelete:nextProps.deviceDelete
      });
     }
     if (this.props.deviceState !== nextProps.deviceState) {
      this.setState({
        deviceState:nextProps.deviceState
      });
     }
     if (this.props.deviceShare !== nextProps.deviceShare) {
      this.setState({
        deviceShare:nextProps.deviceShare
      });
     }
     if (this.props.emailList !== nextProps.emailList) {
      this.setState({
        emailList:nextProps.emailList.list,
        selectedEmail:nextProps.emailList.list[0]
      });
     }
  }

  componentDidMount() {
    this.props.deviceGet();
    this.props.getEmailList()
  }

  addOnChange =(e) =>{
    const name = e.target.name;
    const value = e.target.value
    this.state.addDevice[name] = value;
    this.setState({
      addDevice: this.state.addDevice
    })
  }

  updateOnChange =(e) =>{
    const name = e.target.name;
    const value = e.target.value
    this.state.updateDevice[name] = value;
    this.setState({
      updateDevice: this.state.updateDevice
    })
  }

  shareOnChange =(e) =>{
    const value = e.target.value;
    this.setState({
      selectedEmail: value
    })
  }

  handleUpdate = ()=>{
  this.props.deviceUpdate(this.state.updateDevice)
  this.props.deviceGet()
  this.updateHandleClose()
  }

  handleShare =()=>{
    const obj ={
      id : this.state.shareObj.id,
      email: this.state.selectedEmail
    }
    this.props.deviceShare(obj)
    this.shareHandleClose()
  }

  handleAdd = ()=>{
    this.props.deviceAdd( this.state.addDevice)
    this.addHandleClose();
  }

  alertOk =()=>{
    if(this.state.alertType == "delete"){
      const obj = {
        id : this.state.alertObj.id
      }
      this.props.deviceDelete(obj)
      this.alertHandleClose()
    }else if(this.state.alertType == "state"){
      const obj = {
        id : this.state.alertObj.id,
        currentState: this.state.alertObj.currentState == "1" ? "0" : "1"
      }
      this.props.deviceState(obj)
      this.alertHandleClose()
    }
  }

  handleAddModel = ()=>{
    this.setState({
      addOpen: true,
    })
  }
  

  handleUpdateModel = (item)=>{
    this.setState({
      updateOpen: true,
      updateDevice:item,
    })
  }

  handleShareModel = (item)=> {

    this.setState({
      shareOpen: true,
        shareObj: item
    })
  }

  handleAlertModel =(obj,type, info)=>{
    this.setState({
      alertOpen: true,
      alertInfo:info,
      alertObj:obj,
      alertType:type
    })
  }

  handleAddModel = ()=>{
    this.setState({
      addOpen: true,
    })
  }

  addHandleClose  =()=>{
    this.setState({
      addOpen: false,
      addDevice:{}
    },()=>{
      this.props.deviceGet()
    })
  }

  updateHandleClose =()=>{
    this.setState({
      updateOpen: false,
      updateDevice:{}
    })
  }

  shareHandleClose =()=>{
    this.setState({
      shareOpen: false,
      selectedEmail:'',
      shareObj:{}
    },()=>{
      this.props.deviceGet()
    })
  }
  alertHandleClose =()=>{
    this.setState({
      alertOpen: false,
      alertInfo:'',
      alertObj:{},
      alertType:''
    },()=>{
      this.props.deviceGet()
    })
  }

  table = ()=>{
    return(
      <div>
      {this.state.deviceList.length >0 && (
        <table class="table table-bordered">
          <thead>
              <tr>
              <th>Device Name</th>
              <th>Current State</th>
              <th>Device Type</th>
              <th>Edit</th>
              <th>Delete</th>
              <th>Share device</th>
              </tr>
          </thead>
          <tbody>
              {
                this.state.deviceList.map((item, i)=>{
                return (<tr>
                <td>{item.name}</td>
                <td>
                  {item.currentState == 1 ? 'ON' : 'OFF' }
                <div>
                <button type="button" class="btn btn-primary" data-toggle="modal" onClick={()=>this.handleAlertModel(item,'state', `Are you sure to want ${!item.currentState == 1 ? 'ON' : 'OFF' }`)}  data-target="#myModal">
                    Change status
                </button>
                </div>
                </td>
                <td>{item.devType}</td>
                <td>
                <button type="button" class="btn btn-primary" data-toggle="modal" onClick={()=>this.handleUpdateModel(item, i)}  data-target="#myModal">
                    Edit
                </button>
                </td>
                <td>
                <button type="button" class="btn btn-primary" data-toggle="modal" onClick={()=>this.handleAlertModel(item,'delete', "Are you sure to want delete")}  data-target="#myModal">
                    Delete
                </button>
                </td>
                <td>
                <button type="button" class="btn btn-primary" data-toggle="modal" onClick={()=>this.handleShareModel(item)}  data-target="#myModal">
                    Share
                </button>
                </td>
                </tr>)
                })
              }
          </tbody>
        </table>
      )}
      </div>
    )
  }

  addModel =()=>{
    return (
      <div>
        <Dialog
          open={this.state.addOpen}
          onClose={this.addHandleClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
          >
        <DialogTitle id="alert-dialog-title">{"Alert"}</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
          <div class="form-group">
              <label for="usr">Device Name:</label>
              <input  name = 'name' type="text" class="form-control" id="usr" value={this.state.addDevice.name}   onChange ={this.addOnChange}/>
          </div>
          <div>
          <label for="sel1">Device state:</label>
          <form action="">
            <input type="radio" name="currentState" value={"1"}  onChange={this.addOnChange} /> ON<br />
            <input type="radio" name="currentState" value={"0"}  onChange={this.addOnChange} /> OFF<br />
          </form>
          </div>
          <div class="form-group">
            <label for="sel1">Device type (select one):</label>
            <select name ='devType' class="form-control" id="sel1" value={this.state.addDevice.devType}     onChange={this.addOnChange}>
              <option>AA</option>
              <option>BB</option>
              <option>CC</option>
              <option>DD</option>
            </select>
          </div>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={this.addHandleClose} color="primary">
            Chancel
          </Button>
          <Button onClick={this.handleAdd} color="primary" autoFocus>
            Add
          </Button>
        </DialogActions>
        </Dialog>
      </div>
    )
  }

  shareModel =()=>{
    return (
      <div>
        <Dialog
          open={this.state.shareOpen}
          onClose={this.shareHandleClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">{"Alert"}</DialogTitle>
          <DialogContent>
            <DialogContentText id="alert-dialog-description">
            <div class="form-group">
              <label for="sel1">Share to any one:</label>
              <select name ='devType' class="form-control" id="sel1" value={this.state.selectedEmail}     onChange={this.shareOnChange}>
                {this.state.emailList.length >0 && this.state.emailList.map(item=>(
                <option value ={item}>{item}</option>
                ))}
              </select>
            </div>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.shareHandleClose} color="primary">
              Chancel
            </Button>
            <Button onClick={this.handleShare} color="primary" autoFocus>
              Share
            </Button>
          </DialogActions>
        </Dialog>
  </div>
    )
  }


  updateModel =()=>{
    return (
      <div>
        <Dialog
          open={this.state.updateOpen}
          onClose={this.updateHandleClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">{"Alert"}</DialogTitle>
          <DialogContent>
            <DialogContentText id="alert-dialog-description">
            {/* <form name="form" onSubmit={this.state.handleSubmit}> */}
            <div class="form-group">
                <label for="usr">Device Name:</label>
                <input  name = 'name' type="text" class="form-control" id="usr" value={this.state.updateDevice.name}   onChange ={this.updateOnChange}/>
            </div>
            <div class="form-group">
          <label for="sel1">Device type (select one):</label>
          <select name ='devType' class="form-control" id="sel1" value={this.state.updateDevice.devType}     onChange={this.updateOnChange}>
            <option>AA</option>
            <option>BB</option>
            <option>CC</option>
            <option>DD</option>
          </select>
            </div>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.updateHandleClose} color="primary">
              Chancel
            </Button>
            <Button onClick={this.handleUpdate} color="primary" autoFocus>
              Update
            </Button>
          </DialogActions>
      </Dialog>
     </div>
    )
  }

  alertModel =()=>{
    return (
      <div>
        <Dialog
          open={this.state.alertOpen}
          onClose={this.alertHandleClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">{"Alert"}</DialogTitle>
          <DialogContent>
            <DialogContentText id="alert-dialog-description">
            {this.state.alertInfo}
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.alertHandleClose} color="primary">
              Chancel
            </Button>
            <Button onClick={this.alertOk} color="primary" autoFocus>
              Ok
            </Button>
          </DialogActions>
        </Dialog>
      </div>
    )
  }


  render() {
    return( <div>
      <div>
        <div>
        <button type="button" class="btn btn-primary" data-toggle="modal" onClick={()=>this.handleAddModel()}  data-target="#myModal">
            Add Device
        </button>
        </div>
        {this.addModel()}
        {this.updateModel()}
        {this.alertModel()}
        {this.shareModel()}
      </div>
      {this.table()}
    </div>)

  }
}
const mapStateToProps = state => {
  return {
    deviceList: state.deviceReducer.deviceList,
    deviceAdd :state.deviceReducer.deviceAdd,  
    deviceUpdate :state.deviceReducer.deviceUpdate,
    deviceDelete :state.deviceReducer.deviceDelete,
    deviceState:state.deviceReducer.deviceState,
    deviceShare:state.deviceReducer.deviceShare,
    emailList:state.deviceReducer.emailList
  }

}

export default connect(
  mapStateToProps,
  { deviceGet,deviceAdd,deviceUpdate,deviceDelete,deviceState,getEmailList,deviceShare }
)(Protected);
