const db = require("../models");
const User = db.user;
const Device = db.device;

exports.create = (req, res) => {
  // if(!req.body.name || !req.body.devType || !req.body.currentState){
  //   res.status(500).send({ message: "Please send name, devType, currentState fields" });
  // }
    User.find({_id : req.userId})
    .exec((err, user) => {
        if (err) {
            res.status(500).send({ message: err });
            return;
        }
        const device = new Device({
        user_id: req.userId,
        name: req.body.name,
        devType: req.body.devType,
        currentState: req.body.currentState,
        accessUserList:[user[0].email],
        lastUpdate:Date.now()
      });

      device.save((err, device) => {
        if (err) {
          res.status(500).send({ message: err });
          return;
        }
        res.send({ message: "Device was registered successfully!" });
    })
    })

}
exports.read = (req, res) => {
    User.find({_id : req.userId})
    .exec((err, user) => {
        if (err) {
            res.status(500).send({ message: err });
            return;
        }
        Device.find({
            accessUserList:  user[0].email,
        })
    .exec((err, devices) => {
        if (err) {
            res.status(500).send({ message: err });
            return;
        }
        if (!devices) {
        return res.status(404).send({ message: "Devices Not found." });
        }
        let sendData = [];
        for(let i=0; i<devices.length; i++){
            let obj = {};
            obj['id'] = devices[i]._id;
            obj['name'] = devices[i].name;
            obj['currentState'] = devices[i].currentState;
            obj['devType'] = devices[i].devType;
            sendData.push(obj);
        }
        res.status(200).send(sendData);
    });
    })
}

exports.edit = (req, res) => {
  // if(!req.body.name || !req.body.devType){
  //   res.status(500).send({ message: "Please send name, devType fields" });
  // }
      let updateDevice = {
        name: req.body.name,
        devType: req.body.devType,
        lastUpdate:Date.now()
      }
    Device.update({_id:req.body.id},{$set :updateDevice})
    .exec((err, devices) => {
      if (err) {
        res.status(500).send({ message: err });
        return;
      }

      if (!devices) {
        return res.status(404).send({ message: "Something went wrong." });
      }

      res.status(200).send({message :'Successfully updated'});
    });
}
exports.delete = (req, res) => {
  // if(!req.body.id){
  //   res.status(500).send({ message: "Please send id" });
  // }
  Device.remove({_id:req.body.id})
  .exec((err, devices) => {
    if (err) {
      res.status(500).send({ message: err });
      return;
    }
    if (!devices) {
      return res.status(404).send({ message: "Something went wrong." });
    }
    res.status(200).send({message :'Successfully deleted'});
  });
}

exports.currentState = (req, res) => {
  // if(!req.body.currentState || !req.body.id){
  //   res.status(500).send({ message: "Please send currentState" });
  // }
  let updateDevice = {
      currentState: req.body.currentState,
    }
    Device.update({_id:req.body.id},{$set :updateDevice})
    .exec((err, devices) => {
      if (err) {
        res.status(500).send({ message: err });
        return;
      }
      if (!devices) {
        return res.status(404).send({ message: "Something went wrong." });
      }
      res.status(200).send({message :'Successfully modified current state'});
    });
  }

  exports.share = (req, res) => {
    // if(!req.body.id){
    //   res.status(500).send({ message: "Please send id" });
    // }
    Device.findOne({_id : req.body.id})
    .exec((err, device) => {
        if (err) {
            res.status(500).send({ message: err });
            return;
        }
        if (!device) {
            return res.status(404).send({ message: "Device Not found." });
        }
        device['accessUserList'].push(req.body.email)
        Device.update({_id: device._id},{$set :device})
        .exec((err, devices) => {
          if (err) {
            res.status(500).send({ message: err });
            return;
          }
          if (!devices) {
            return res.status(404).send({ message: "Something went wrong." });
          }
          res.status(200).send({message :'Successfully shared device to user'});
        });
    //  res.status(200).send({message :'Successfully shared device to user'});
    })
  }

  exports.emailList = (req, res) => {
    User.find()
    .exec((err, users) => {
        if (err) {
            res.status(500).send({ message: err });
            return;
        }
        if (!users) {
            return res.status(404).send({ message: "users Not found." });
        }
        const id = req.userId;
        const list = []
        for(let i=0; i< users.length; i++) {
            if(users[i]._id != id){
               
                list.push(users[i].email)
            }
        }
     res.status(200).send({list});
    })
  }