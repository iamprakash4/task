const { authJwt } = require("../middlewares");
const controller = require("../controllers/device.controller");

module.exports = function(app) {
  app.use(function(req, res, next) {
    res.header(
      "Access-Control-Allow-Headers",
      "access-token, Origin, Content-Type, Accept"
    );
    next();
  });
  app.post("/api/device/create", [authJwt.verifyToken], controller.create);
  app.get("/api/device/read", [authJwt.verifyToken], controller.read);
  app.put("/api/device/edit", [authJwt.verifyToken], controller.edit);
  app.delete("/api/device/delete", [authJwt.verifyToken], controller.delete);
  app.put("/api/device/currentState", [authJwt.verifyToken], controller.currentState);
  app.put("/api/device/share", [authJwt.verifyToken], controller.share);
  app.get("/api/device/emailList", [authJwt.verifyToken], controller.emailList);
};
