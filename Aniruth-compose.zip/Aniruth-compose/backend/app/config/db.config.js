module.exports = {
  HOST: "mongodb",
  PORT: 27017,
  DB: "bezkoder_db"
};